class Cars {
  static List types = [];

}