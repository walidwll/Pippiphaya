class Locales {
  // static List cities = [
  //   {'value': 'tunis', 'label': 'Tunis'},
  //   {'value': 'ariana', 'label': 'Ariana'},
  //   {'value': 'benarous', 'label': 'Ben Arous'},
  //   {'value': 'manouba', 'label': 'Manouba'},
  //   {'value': 'nabeul', 'label': 'Nabeul'},
  //   {'value': 'zaghouan', 'label': 'Zaghouan'},
  //   {'value': 'bizerte', 'label': 'Bizerte'},
  //   {'value': 'beja', 'label': 'Béja'},
  //   {'value': 'jendouba', 'label': 'Jendouba'},
  //   {'value': 'kef', 'label': 'Kef'},
  //   {'value': 'siliana', 'label': 'Siliana'},
  //   {'value': 'sousse', 'label': 'Sousse'},
  //   {'value': 'monastir', 'label': 'Monastir'},
  //   {'value': 'mahdia', 'label': 'Mahdia'},
  //   {'value': 'kairouan', 'label': 'Kairouan'},
  //   {'value': 'kasserine', 'label': 'Kasserine'},
  //   {'value': 'gabes', 'label': 'Gabès'},
  //   {'value': 'tataouine', 'label': 'Tataouine'},
  //   {'value': 'gafsa', 'label': 'Gafsa'},
  //   {'value': 'tozeur', 'label': 'Tozeur'},
  //   {'value': 'kebili', 'label': 'Kebili'}
  // ];
  static List cities = [
    'Tunis', 'Ariana', 'Ben Arous',
    'Manouba', 'Nabeul','Zaghouan',
    'Bizerte', 'Béja', 'Jendouba',
    'Kef', 'Siliana', 'Sousse',
    'Monastir', 'Mahdia', 'Kairouan',
    'Kasserine', 'Gabès', 'Tataouine',
    'Gafsa', 'Tozeur','Kebili'
  ];
}